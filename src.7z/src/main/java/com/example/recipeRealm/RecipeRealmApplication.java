package com.example.recipeRealm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeRealmApplication {
    public static void main(String[] args) {
        SpringApplication.run(RecipeRealmApplication.class, args);
    }

}
