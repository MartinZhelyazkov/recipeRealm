package com.example.recipeRealm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequest {
    @NotNull(message = "Email can't be null")
    private String email;
    @NotNull(message = "Password can't be null")
    private String password;
}
