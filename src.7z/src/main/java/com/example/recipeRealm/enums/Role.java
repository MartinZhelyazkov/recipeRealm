package com.example.recipeRealm.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_MODERATOR
}
