package com.example.recipeRealm.service.impl;
import com.example.recipeRealm.model.User;
import com.example.recipeRealm.service.UserService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
@Service
public class CurrentUserService {
    private final UserService userService;

    public CurrentUserService(UserService userService) {
        this.userService = userService;
    }
    public Boolean isCurrentUserMatch(User recipeOrCommentOwner){
        User currentUser = exctractCurrentUser();
        if(currentUser!=null && recipeOrCommentOwner != null){
            return recipeOrCommentOwner.getEmail().equals(exctractCurrentUser().getEmail());
        }
        return false;
    }

    public User exctractCurrentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return (User) principal;
    }
}
