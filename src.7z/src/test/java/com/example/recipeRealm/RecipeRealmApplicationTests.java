package com.example.recipeRealm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeRealmApplicationTests {

	@Test
	void contextLoads() {
	}

}
